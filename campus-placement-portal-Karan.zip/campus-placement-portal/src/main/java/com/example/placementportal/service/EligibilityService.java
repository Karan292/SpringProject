package com.example.placementportal.service;

import com.example.placementportal.entity.JobOpportunity;
import com.example.placementportal.entity.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Service
public class EligibilityService {

    public boolean isEligible(Student student, JobOpportunity job) {
        return getEligibilityIssues(student, job).isEmpty();
    }

    public List<String> getEligibilityIssues(Student student, JobOpportunity job) {
        List<String> issues = new ArrayList<>();

        if (student == null || job == null) {
            issues.add("Student or job record not found.");
            return issues;
        }

        if (student.getCgpa() == null || job.getRequiredCgpa() == null || student.getCgpa() < job.getRequiredCgpa()) {
            issues.add("CGPA is below the company requirement.");
        }

        if (!branchMatches(student.getBranch(), job.getEligibleBranches())) {
            issues.add("Branch does not match the company criteria.");
        }

        int studentBacklogs = student.getBacklogs() == null ? 0 : student.getBacklogs();
        int maxBacklogs = job.getMaxAllowedBacklogs() == null ? 0 : job.getMaxAllowedBacklogs();
        if (studentBacklogs > maxBacklogs) {
            issues.add("Backlogs are more than allowed limit.");
        }

        List<String> missingSkills = findMissingSkills(student.getSkills(), job.getRequiredSkills());
        if (!missingSkills.isEmpty()) {
            issues.add("Missing required skills: " + String.join(", ", missingSkills));
        }

        return issues;
    }

    private boolean branchMatches(String studentBranch, String eligibleBranches) {
        if (eligibleBranches == null || eligibleBranches.isBlank()) {
            return true;
        }
        if ("ALL".equalsIgnoreCase(eligibleBranches.trim())) {
            return true;
        }
        if (studentBranch == null || studentBranch.isBlank()) {
            return false;
        }

        String normalizedStudentBranch = studentBranch.trim().toLowerCase(Locale.ROOT);
        return Arrays.stream(eligibleBranches.split(","))
                .map(branch -> branch.trim().toLowerCase(Locale.ROOT))
                .anyMatch(branch -> branch.equals(normalizedStudentBranch));
    }

    private List<String> findMissingSkills(String studentSkills, String requiredSkills) {
        List<String> missing = new ArrayList<>();
        if (requiredSkills == null || requiredSkills.isBlank()) {
            return missing;
        }
        String normalizedStudentSkills = studentSkills == null ? "" : studentSkills.toLowerCase(Locale.ROOT);
        for (String skill : requiredSkills.split(",")) {
            String cleanSkill = skill.trim();
            if (!cleanSkill.isBlank() && !normalizedStudentSkills.contains(cleanSkill.toLowerCase(Locale.ROOT))) {
                missing.add(cleanSkill);
            }
        }
        return missing;
    }
}
