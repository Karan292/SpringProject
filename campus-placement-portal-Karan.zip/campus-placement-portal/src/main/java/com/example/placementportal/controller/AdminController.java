package com.example.placementportal.controller;

import com.example.placementportal.entity.Company;
import com.example.placementportal.repository.CompanyRepository;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import com.example.placementportal.service.ReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminController {

    private final StudentRepository studentRepository;
    private final CompanyRepository companyRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;
    private final ReportService reportService;

    public AdminController(StudentRepository studentRepository,
                           CompanyRepository companyRepository,
                           JobOpportunityRepository jobOpportunityRepository,
                           JobApplicationRepository jobApplicationRepository,
                           ReportService reportService) {
        this.studentRepository = studentRepository;
        this.companyRepository = companyRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
        this.reportService = reportService;
    }

    @GetMapping("/admin")
    public String adminDashboard(Model model) {
        model.addAttribute("totalStudents", reportService.totalStudents());
        model.addAttribute("totalCompanies", companyRepository.count());
        model.addAttribute("totalActiveJobs", reportService.totalActiveJobs());
        model.addAttribute("totalApplications", reportService.totalApplications());
        model.addAttribute("totalPlaced", reportService.totalPlacedStudents());
        model.addAttribute("placementPercentage", reportService.placementPercentage());
        return "admin/dashboard";
    }

    @GetMapping("/admin/students")
    public String manageStudents(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        return "admin/students";
    }

    @GetMapping("/admin/students/{id}/delete")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        studentRepository.deleteById(id);
        redirectAttributes.addFlashAttribute("success", "Student deleted successfully.");
        return "redirect:/admin/students";
    }

    @GetMapping("/admin/companies")
    public String manageCompanies(Model model) {
        model.addAttribute("companies", companyRepository.findAll());
        return "admin/companies";
    }

    @GetMapping("/admin/companies/{id}/toggle-verify")
    public String toggleCompanyVerification(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Company company = companyRepository.findById(id).orElse(null);
        if (company != null) {
            company.setVerified(!Boolean.TRUE.equals(company.getVerified()));
            companyRepository.save(company);
            redirectAttributes.addFlashAttribute("success", "Company verification updated.");
        }
        return "redirect:/admin/companies";
    }

    @GetMapping("/admin/jobs")
    public String manageJobs(Model model) {
        model.addAttribute("jobs", jobOpportunityRepository.findAll());
        return "admin/jobs";
    }

    @GetMapping("/admin/jobs/{id}/toggle-active")
    public String toggleJobStatus(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        jobOpportunityRepository.findById(id).ifPresent(job -> {
            job.setActive(!Boolean.TRUE.equals(job.getActive()));
            jobOpportunityRepository.save(job);
        });
        redirectAttributes.addFlashAttribute("success", "Job status updated.");
        return "redirect:/admin/jobs";
    }

    @GetMapping("/admin/applications")
    public String monitorApplications(Model model) {
        model.addAttribute("applications", jobApplicationRepository.findAll());
        return "admin/applications";
    }

    @GetMapping("/admin/reports")
    public String reports(Model model) {
        model.addAttribute("totalStudents", reportService.totalStudents());
        model.addAttribute("totalApplications", reportService.totalApplications());
        model.addAttribute("totalPlaced", reportService.totalPlacedStudents());
        model.addAttribute("placementPercentage", reportService.placementPercentage());
        model.addAttribute("highestPackage", reportService.highestPackage());
        model.addAttribute("averagePackage", reportService.averagePackage());
        model.addAttribute("companyWise", jobApplicationRepository.companyWisePlacements(reportService.placedStatuses()));
        model.addAttribute("branchWise", jobApplicationRepository.branchWisePlacements(reportService.placedStatuses()));
        return "admin/reports";
    }
}
