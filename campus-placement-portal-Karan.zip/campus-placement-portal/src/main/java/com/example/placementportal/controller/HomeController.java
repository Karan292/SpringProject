package com.example.placementportal.controller;

import com.example.placementportal.repository.CompanyRepository;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final StudentRepository studentRepository;
    private final CompanyRepository companyRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;

    public HomeController(StudentRepository studentRepository,
                          CompanyRepository companyRepository,
                          JobOpportunityRepository jobOpportunityRepository,
                          JobApplicationRepository jobApplicationRepository) {
        this.studentRepository = studentRepository;
        this.companyRepository = companyRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("studentCount", studentRepository.count());
        model.addAttribute("companyCount", companyRepository.count());
        model.addAttribute("jobCount", jobOpportunityRepository.countByActiveTrue());
        model.addAttribute("applicationCount", jobApplicationRepository.count());
        return "index";
    }
}
