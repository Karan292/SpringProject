package com.example.placementportal.controller;

import com.example.placementportal.repository.JobOpportunityRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class JobController {

    private final JobOpportunityRepository jobOpportunityRepository;

    public JobController(JobOpportunityRepository jobOpportunityRepository) {
        this.jobOpportunityRepository = jobOpportunityRepository;
    }

    @GetMapping("/jobs")
    public String publicJobs(Model model) {
        model.addAttribute("jobs", jobOpportunityRepository.findByActiveTrueOrderByDriveDateAsc());
        return "jobs/list";
    }
}
