package com.example.placementportal.entity;

public enum ApplicationStatus {
    APPLIED,
    SHORTLISTED,
    INTERVIEW_SCHEDULED,
    SELECTED,
    REJECTED,
    WAITING_LIST,
    OFFER_RELEASED
}
