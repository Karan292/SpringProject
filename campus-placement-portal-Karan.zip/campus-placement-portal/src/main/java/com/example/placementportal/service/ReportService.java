package com.example.placementportal.service;

import com.example.placementportal.entity.ApplicationStatus;
import com.example.placementportal.entity.JobApplication;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

@Service
public class ReportService {

    private final StudentRepository studentRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;

    public ReportService(StudentRepository studentRepository,
                         JobOpportunityRepository jobOpportunityRepository,
                         JobApplicationRepository jobApplicationRepository) {
        this.studentRepository = studentRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
    }

    public List<ApplicationStatus> placedStatuses() {
        return Arrays.asList(ApplicationStatus.SELECTED, ApplicationStatus.OFFER_RELEASED);
    }

    public long totalStudents() {
        return studentRepository.count();
    }

    public long totalActiveJobs() {
        return jobOpportunityRepository.countByActiveTrue();
    }

    public long totalApplications() {
        return jobApplicationRepository.count();
    }

    public long totalPlacedStudents() {
        return jobApplicationRepository.countDistinctStudentsByStatuses(placedStatuses());
    }

    public BigDecimal placementPercentage() {
        long total = totalStudents();
        if (total == 0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(totalPlacedStudents())
                .multiply(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(total), 2, RoundingMode.HALF_UP);
    }

    public BigDecimal highestPackage() {
        return jobApplicationRepository.findAll().stream()
                .filter(app -> placedStatuses().contains(app.getStatus()))
                .map(JobApplication::getJobOpportunity)
                .filter(job -> job.getPackageLpa() != null)
                .map(job -> job.getPackageLpa())
                .max(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);
    }

    public BigDecimal averagePackage() {
        List<BigDecimal> packages = jobApplicationRepository.findAll().stream()
                .filter(app -> placedStatuses().contains(app.getStatus()))
                .map(JobApplication::getJobOpportunity)
                .filter(job -> job.getPackageLpa() != null)
                .map(job -> job.getPackageLpa())
                .toList();
        if (packages.isEmpty()) {
            return BigDecimal.ZERO;
        }
        BigDecimal total = packages.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        return total.divide(BigDecimal.valueOf(packages.size()), 2, RoundingMode.HALF_UP);
    }
}
