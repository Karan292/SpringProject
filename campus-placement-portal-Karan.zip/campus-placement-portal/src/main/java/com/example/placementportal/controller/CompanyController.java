package com.example.placementportal.controller;

import com.example.placementportal.entity.ApplicationStatus;
import com.example.placementportal.entity.Company;
import com.example.placementportal.entity.JobApplication;
import com.example.placementportal.entity.JobOpportunity;
import com.example.placementportal.entity.Student;
import com.example.placementportal.repository.CompanyRepository;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import com.example.placementportal.service.EligibilityService;
import jakarta.servlet.http.HttpSession;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class CompanyController {

    private final CompanyRepository companyRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;
    private final StudentRepository studentRepository;
    private final EligibilityService eligibilityService;

    public CompanyController(CompanyRepository companyRepository,
                             JobOpportunityRepository jobOpportunityRepository,
                             JobApplicationRepository jobApplicationRepository,
                             StudentRepository studentRepository,
                             EligibilityService eligibilityService) {
        this.companyRepository = companyRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
        this.studentRepository = studentRepository;
        this.eligibilityService = eligibilityService;
    }

    @GetMapping("/companies/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("company", new Company());
        return "companies/register";
    }

    @PostMapping("/companies/register")
    public String registerCompany(@ModelAttribute Company company, RedirectAttributes redirectAttributes) {
        if (companyRepository.findByEmail(company.getEmail()).isPresent()) {
            redirectAttributes.addFlashAttribute("error", "Email already registered. Please login.");
            return "redirect:/companies/register";
        }
        company.setVerified(true);
        companyRepository.save(company);
        redirectAttributes.addFlashAttribute("success", "Company registered successfully. Please login.");
        return "redirect:/companies/login";
    }

    @GetMapping("/companies/login")
    public String showLoginForm() {
        return "companies/login";
    }

    @PostMapping("/companies/login")
    public String loginCompany(@RequestParam String email,
                               @RequestParam String password,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        return companyRepository.findByEmailAndPassword(email, password)
                .map(company -> {
                    session.setAttribute("companyId", company.getId());
                    session.setAttribute("companyName", company.getCompanyName());
                    return "redirect:/companies/dashboard";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "Invalid email or password.");
                    return "redirect:/companies/login";
                });
    }

    @GetMapping("/companies/logout")
    public String logoutCompany(HttpSession session) {
        session.removeAttribute("companyId");
        session.removeAttribute("companyName");
        return "redirect:/";
    }

    @GetMapping("/companies/dashboard")
    public String companyDashboard(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Company company = getLoggedInCompany(session);
        if (company == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/companies/login";
        }
        model.addAttribute("company", company);
        model.addAttribute("jobs", jobOpportunityRepository.findByCompanyIdOrderByDriveDateDesc(company.getId()));
        model.addAttribute("applications", jobApplicationRepository.findByJobOpportunityCompanyIdOrderByAppliedAtDesc(company.getId()));
        return "companies/dashboard";
    }

    @GetMapping("/companies/jobs/new")
    public String newJobForm(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Company company = getLoggedInCompany(session);
        if (company == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/companies/login";
        }
        JobOpportunity job = new JobOpportunity();
        job.setRequiredCgpa(7.0);
        job.setEligibleBranches("CSE, IT");
        job.setMaxAllowedBacklogs(0);
        model.addAttribute("job", job);
        return "companies/job-form";
    }

    @PostMapping("/companies/jobs/save")
    public String saveJob(@ModelAttribute JobOpportunity job, HttpSession session, RedirectAttributes redirectAttributes) {
        Company company = getLoggedInCompany(session);
        if (company == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/companies/login";
        }
        job.setCompany(company);
        if (job.getActive() == null) {
            job.setActive(true);
        }
        jobOpportunityRepository.save(job);
        redirectAttributes.addFlashAttribute("success", "Placement drive created successfully.");
        return "redirect:/companies/dashboard";
    }

    @GetMapping("/companies/jobs/{jobId}/applications")
    public String viewApplications(@PathVariable Long jobId, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Company company = getLoggedInCompany(session);
        if (company == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/companies/login";
        }

        JobOpportunity job = jobOpportunityRepository.findById(jobId).orElse(null);
        if (job == null || !job.getCompany().getId().equals(company.getId())) {
            redirectAttributes.addFlashAttribute("error", "Invalid job selected.");
            return "redirect:/companies/dashboard";
        }

        List<Student> allStudents = studentRepository.findAll();
        List<Student> eligibleStudents = allStudents.stream()
                .filter(student -> eligibilityService.isEligible(student, job))
                .toList();

        model.addAttribute("job", job);
        model.addAttribute("applications", jobApplicationRepository.findByJobOpportunityIdOrderByAppliedAtDesc(jobId));
        model.addAttribute("eligibleStudents", eligibleStudents);
        model.addAttribute("statuses", ApplicationStatus.values());
        return "companies/applications";
    }

    @PostMapping("/companies/applications/{applicationId}/status")
    public String updateApplicationStatus(@PathVariable Long applicationId,
                                          @RequestParam ApplicationStatus status,
                                          @RequestParam(required = false) String remarks,
                                          @RequestParam(required = false)
                                          @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime interviewDate,
                                          HttpSession session,
                                          RedirectAttributes redirectAttributes) {
        Company company = getLoggedInCompany(session);
        if (company == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/companies/login";
        }

        JobApplication application = jobApplicationRepository.findById(applicationId).orElse(null);
        if (application == null || !application.getJobOpportunity().getCompany().getId().equals(company.getId())) {
            redirectAttributes.addFlashAttribute("error", "Invalid application selected.");
            return "redirect:/companies/dashboard";
        }

        application.setStatus(status);
        application.setRemarks(remarks);
        application.setInterviewDate(interviewDate);
        if (status == ApplicationStatus.SELECTED || status == ApplicationStatus.OFFER_RELEASED) {
            application.getStudent().setPlaced(true);
        }
        jobApplicationRepository.save(application);
        redirectAttributes.addFlashAttribute("success", "Application status updated successfully.");
        return "redirect:/companies/jobs/" + application.getJobOpportunity().getId() + "/applications";
    }

    private Company getLoggedInCompany(HttpSession session) {
        Object companyId = session.getAttribute("companyId");
        if (companyId == null) {
            return null;
        }
        return companyRepository.findById((Long) companyId).orElse(null);
    }
}
