package com.example.placementportal.repository;

import com.example.placementportal.entity.JobOpportunity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobOpportunityRepository extends JpaRepository<JobOpportunity, Long> {
    List<JobOpportunity> findByActiveTrueOrderByDriveDateAsc();
    List<JobOpportunity> findByCompanyIdOrderByDriveDateDesc(Long companyId);
    long countByActiveTrue();
}
