package com.example.placementportal.config;

import com.example.placementportal.entity.ApplicationStatus;
import com.example.placementportal.entity.Company;
import com.example.placementportal.entity.JobApplication;
import com.example.placementportal.entity.JobOpportunity;
import com.example.placementportal.entity.Student;
import com.example.placementportal.repository.CompanyRepository;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final StudentRepository studentRepository;
    private final CompanyRepository companyRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;

    public DataInitializer(StudentRepository studentRepository,
                           CompanyRepository companyRepository,
                           JobOpportunityRepository jobOpportunityRepository,
                           JobApplicationRepository jobApplicationRepository) {
        this.studentRepository = studentRepository;
        this.companyRepository = companyRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
    }

    @Override
    public void run(String... args) {
        if (studentRepository.count() > 0 || companyRepository.count() > 0) {
            return;
        }

        Student rahul = new Student();
        rahul.setFirstName("Rahul");
        rahul.setLastName("Sharma");
        rahul.setEmail("rahul@example.com");
        rahul.setPassword("1234");
        rahul.setPhone("9876543210");
        rahul.setBranch("CSE");
        rahul.setCgpa(8.2);
        rahul.setTenthPercentage(85.0);
        rahul.setTwelfthPercentage(82.0);
        rahul.setGraduationPercentage(81.0);
        rahul.setBacklogs(0);
        rahul.setSkills("Java, Spring Boot, SQL, HTML, CSS");
        studentRepository.save(rahul);

        Student priya = new Student();
        priya.setFirstName("Priya");
        priya.setLastName("Verma");
        priya.setEmail("priya@example.com");
        priya.setPassword("1234");
        priya.setPhone("9876501234");
        priya.setBranch("IT");
        priya.setCgpa(7.6);
        priya.setTenthPercentage(88.0);
        priya.setTwelfthPercentage(84.0);
        priya.setGraduationPercentage(78.0);
        priya.setBacklogs(0);
        priya.setSkills("Python, SQL, Machine Learning, Java");
        studentRepository.save(priya);

        Student amit = new Student();
        amit.setFirstName("Amit");
        amit.setLastName("Kumar");
        amit.setEmail("amit@example.com");
        amit.setPassword("1234");
        amit.setPhone("9876512345");
        amit.setBranch("ECE");
        amit.setCgpa(6.8);
        amit.setTenthPercentage(76.0);
        amit.setTwelfthPercentage(73.0);
        amit.setGraduationPercentage(70.0);
        amit.setBacklogs(1);
        amit.setSkills("Java, Networking, SQL");
        studentRepository.save(amit);

        Company techSoft = new Company();
        techSoft.setCompanyName("TechSoft Solutions");
        techSoft.setEmail("hr@techsoft.com");
        techSoft.setPassword("1234");
        techSoft.setHrName("Neha Singh");
        techSoft.setHrPhone("9000011111");
        techSoft.setWebsite("https://techsoft.example.com");
        techSoft.setCompanyProfile("IT services company hiring freshers for Java development roles.");
        companyRepository.save(techSoft);

        Company cloudNova = new Company();
        cloudNova.setCompanyName("CloudNova Technologies");
        cloudNova.setEmail("hr@cloudnova.com");
        cloudNova.setPassword("1234");
        cloudNova.setHrName("Arjun Mehta");
        cloudNova.setHrPhone("9000022222");
        cloudNova.setWebsite("https://cloudnova.example.com");
        cloudNova.setCompanyProfile("Cloud and analytics company hiring software and data trainees.");
        companyRepository.save(cloudNova);

        JobOpportunity javaJob = new JobOpportunity();
        javaJob.setCompany(techSoft);
        javaJob.setTitle("Java Developer Trainee");
        javaJob.setDescription("Freshers role for Java, Spring Boot and SQL development.");
        javaJob.setRequiredCgpa(7.0);
        javaJob.setEligibleBranches("CSE, IT");
        javaJob.setRequiredSkills("Java, SQL");
        javaJob.setMaxAllowedBacklogs(0);
        javaJob.setPackageLpa(new BigDecimal("5.50"));
        javaJob.setLocation("Bengaluru");
        javaJob.setDriveDate(LocalDate.now().plusDays(10));
        jobOpportunityRepository.save(javaJob);

        JobOpportunity dataJob = new JobOpportunity();
        dataJob.setCompany(cloudNova);
        dataJob.setTitle("Data Analyst Trainee");
        dataJob.setDescription("Entry level analytics role requiring Python, SQL and basic machine learning.");
        dataJob.setRequiredCgpa(7.5);
        dataJob.setEligibleBranches("CSE, IT, ECE");
        dataJob.setRequiredSkills("Python, SQL");
        dataJob.setMaxAllowedBacklogs(1);
        dataJob.setPackageLpa(new BigDecimal("6.25"));
        dataJob.setLocation("Hyderabad");
        dataJob.setDriveDate(LocalDate.now().plusDays(15));
        jobOpportunityRepository.save(dataJob);

        JobApplication demoApplication = new JobApplication();
        demoApplication.setStudent(rahul);
        demoApplication.setJobOpportunity(javaJob);
        demoApplication.setStatus(ApplicationStatus.SHORTLISTED);
        demoApplication.setRemarks("Good academic profile. Shortlisted for technical interview.");
        jobApplicationRepository.save(demoApplication);
    }
}
