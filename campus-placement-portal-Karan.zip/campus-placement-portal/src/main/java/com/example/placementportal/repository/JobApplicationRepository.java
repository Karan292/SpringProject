package com.example.placementportal.repository;

import com.example.placementportal.entity.ApplicationStatus;
import com.example.placementportal.entity.JobApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {
    List<JobApplication> findByStudentIdOrderByAppliedAtDesc(Long studentId);
    List<JobApplication> findByJobOpportunityIdOrderByAppliedAtDesc(Long jobOpportunityId);
    List<JobApplication> findByJobOpportunityCompanyIdOrderByAppliedAtDesc(Long companyId);
    boolean existsByStudentIdAndJobOpportunityId(Long studentId, Long jobOpportunityId);
    long countByStatus(ApplicationStatus status);

    @Query("select count(distinct a.student.id) from JobApplication a where a.status in :statuses")
    long countDistinctStudentsByStatuses(@Param("statuses") Collection<ApplicationStatus> statuses);

    @Query("select a.jobOpportunity.company.companyName, count(distinct a.student.id) " +
           "from JobApplication a where a.status in :statuses " +
           "group by a.jobOpportunity.company.companyName order by count(distinct a.student.id) desc")
    List<Object[]> companyWisePlacements(@Param("statuses") Collection<ApplicationStatus> statuses);

    @Query("select a.student.branch, count(distinct a.student.id) " +
           "from JobApplication a where a.status in :statuses " +
           "group by a.student.branch order by count(distinct a.student.id) desc")
    List<Object[]> branchWisePlacements(@Param("statuses") Collection<ApplicationStatus> statuses);
}
