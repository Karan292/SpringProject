package com.example.placementportal.controller;

import com.example.placementportal.entity.JobApplication;
import com.example.placementportal.entity.JobOpportunity;
import com.example.placementportal.entity.Student;
import com.example.placementportal.repository.JobApplicationRepository;
import com.example.placementportal.repository.JobOpportunityRepository;
import com.example.placementportal.repository.StudentRepository;
import com.example.placementportal.service.EligibilityService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class StudentController {

    private final StudentRepository studentRepository;
    private final JobOpportunityRepository jobOpportunityRepository;
    private final JobApplicationRepository jobApplicationRepository;
    private final EligibilityService eligibilityService;

    @Value("${app.upload.dir}")
    private String uploadDir;

    public StudentController(StudentRepository studentRepository,
                             JobOpportunityRepository jobOpportunityRepository,
                             JobApplicationRepository jobApplicationRepository,
                             EligibilityService eligibilityService) {
        this.studentRepository = studentRepository;
        this.jobOpportunityRepository = jobOpportunityRepository;
        this.jobApplicationRepository = jobApplicationRepository;
        this.eligibilityService = eligibilityService;
    }

    @GetMapping("/students/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("student", new Student());
        return "students/register";
    }

    @PostMapping("/students/register")
    public String registerStudent(@ModelAttribute Student student, RedirectAttributes redirectAttributes) {
        if (studentRepository.findByEmail(student.getEmail()).isPresent()) {
            redirectAttributes.addFlashAttribute("error", "Email already registered. Please login.");
            return "redirect:/students/register";
        }
        studentRepository.save(student);
        redirectAttributes.addFlashAttribute("success", "Student registered successfully. Please login.");
        return "redirect:/students/login";
    }

    @GetMapping("/students/login")
    public String showLoginForm() {
        return "students/login";
    }

    @PostMapping("/students/login")
    public String loginStudent(@RequestParam String email,
                               @RequestParam String password,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        return studentRepository.findByEmailAndPassword(email, password)
                .map(student -> {
                    session.setAttribute("studentId", student.getId());
                    session.setAttribute("studentName", student.getFullName());
                    return "redirect:/students/dashboard";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "Invalid email or password.");
                    return "redirect:/students/login";
                });
    }

    @GetMapping("/students/logout")
    public String logoutStudent(HttpSession session) {
        session.removeAttribute("studentId");
        session.removeAttribute("studentName");
        return "redirect:/";
    }

    @GetMapping("/students/dashboard")
    public String studentDashboard(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Student student = getLoggedInStudent(session);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/students/login";
        }

        List<JobOpportunity> jobs = jobOpportunityRepository.findByActiveTrueOrderByDriveDateAsc();
        Map<Long, Boolean> eligibilityMap = new HashMap<>();
        Map<Long, Boolean> appliedMap = new HashMap<>();
        Map<Long, List<String>> issueMap = new HashMap<>();

        for (JobOpportunity job : jobs) {
            eligibilityMap.put(job.getId(), eligibilityService.isEligible(student, job));
            appliedMap.put(job.getId(), jobApplicationRepository.existsByStudentIdAndJobOpportunityId(student.getId(), job.getId()));
            issueMap.put(job.getId(), eligibilityService.getEligibilityIssues(student, job));
        }

        model.addAttribute("student", student);
        model.addAttribute("jobs", jobs);
        model.addAttribute("applications", jobApplicationRepository.findByStudentIdOrderByAppliedAtDesc(student.getId()));
        model.addAttribute("eligibilityMap", eligibilityMap);
        model.addAttribute("appliedMap", appliedMap);
        model.addAttribute("issueMap", issueMap);
        return "students/dashboard";
    }

    @GetMapping("/students/profile")
    public String editProfile(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Student student = getLoggedInStudent(session);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/students/login";
        }
        model.addAttribute("student", student);
        return "students/profile";
    }

    @PostMapping("/students/profile")
    public String updateProfile(@ModelAttribute Student formStudent,
                                @RequestParam(required = false) MultipartFile resume,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        Student student = getLoggedInStudent(session);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/students/login";
        }

        student.setFirstName(formStudent.getFirstName());
        student.setLastName(formStudent.getLastName());
        student.setPhone(formStudent.getPhone());
        student.setBranch(formStudent.getBranch());
        student.setCgpa(formStudent.getCgpa());
        student.setTenthPercentage(formStudent.getTenthPercentage());
        student.setTwelfthPercentage(formStudent.getTwelfthPercentage());
        student.setGraduationPercentage(formStudent.getGraduationPercentage());
        student.setBacklogs(formStudent.getBacklogs());
        student.setSkills(formStudent.getSkills());

        if (resume != null && !resume.isEmpty()) {
            try {
                String savedFileName = saveResumeFile(resume);
                student.setResumeFileName(savedFileName);
            } catch (IOException e) {
                redirectAttributes.addFlashAttribute("error", "Could not upload resume: " + e.getMessage());
                return "redirect:/students/profile";
            }
        }

        studentRepository.save(student);
        redirectAttributes.addFlashAttribute("success", "Profile updated successfully.");
        return "redirect:/students/dashboard";
    }

    @PostMapping("/students/jobs/{jobId}/apply")
    public String applyForJob(@PathVariable Long jobId, HttpSession session, RedirectAttributes redirectAttributes) {
        Student student = getLoggedInStudent(session);
        if (student == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/students/login";
        }

        JobOpportunity job = jobOpportunityRepository.findById(jobId).orElse(null);
        if (job == null) {
            redirectAttributes.addFlashAttribute("error", "Job not found.");
            return "redirect:/students/dashboard";
        }

        if (jobApplicationRepository.existsByStudentIdAndJobOpportunityId(student.getId(), jobId)) {
            redirectAttributes.addFlashAttribute("error", "You already applied for this job.");
            return "redirect:/students/dashboard";
        }

        if (!eligibilityService.isEligible(student, job)) {
            redirectAttributes.addFlashAttribute("error", "You are not eligible for this job: " + String.join(" ", eligibilityService.getEligibilityIssues(student, job)));
            return "redirect:/students/dashboard";
        }

        JobApplication application = new JobApplication();
        application.setStudent(student);
        application.setJobOpportunity(job);
        jobApplicationRepository.save(application);
        redirectAttributes.addFlashAttribute("success", "Application submitted successfully.");
        return "redirect:/students/dashboard";
    }

    private Student getLoggedInStudent(HttpSession session) {
        Object studentId = session.getAttribute("studentId");
        if (studentId == null) {
            return null;
        }
        return studentRepository.findById((Long) studentId).orElse(null);
    }

    private String saveResumeFile(MultipartFile resume) throws IOException {
        Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
        Files.createDirectories(uploadPath);
        String originalFileName = resume.getOriginalFilename() == null ? "resume.pdf" : resume.getOriginalFilename();
        String safeFileName = System.currentTimeMillis() + "_" + originalFileName.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path filePath = uploadPath.resolve(safeFileName);
        Files.copy(resume.getInputStream(), filePath);
        return safeFileName;
    }
}
